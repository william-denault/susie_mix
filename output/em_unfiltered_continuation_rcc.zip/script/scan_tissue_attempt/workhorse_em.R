# Fit only weighted mixed-coding SuSiE, using one prior row per tissue.
# Called by run_em_chunk.R with the iteration's immutable priors.csv.
run_susie_gene <- function(
    target_gene = "GTF2H2",
    tissue_priors,

    # --- paths ---
    project_dir = Sys.getenv(
      "SUSIE_MIX_PROJECT_DIR", "/project2/mstephens/wdenault/susie_mix"
    ),
    datadir = "/project2/mstephens/gtex",
    plink_exec = file.path(datadir, "plink2"),
    gene_annot_fun = file.path(
      project_dir, "script/scan_tissue_attempt/get_gene_annotations.R"
    ),
    gtf_file = file.path(
      datadir,
      "Homo_sapiens.GRCh38.103.chr.reformatted.collapse_only.gene.gtf.gz"
    ),
    geno_file = file.path(
      datadir,
      "GTEx_Analysis_2017-06-05_v8_WholeGenomeSeq_866Indiv"
    ),
    subject_pheno_file = file.path(
      datadir,
      "GTEx_Analysis_v8_Annotations_SubjectPhenotypesDS.txt.gz"
    ),
    sample_attr_file = file.path(
      datadir,
      "GTEx_Analysis_v8_Annotations_SampleAttributesDS.txt.gz"
    ),
    expr_file = file.path(
      datadir,
      "GTEx_Analysis_2017-06-05_v8_RNASeQCv1.1.9_gene_reads.gct.gz"
    ),

    # --- analysis parameters ---
    min_maf_plink = 0.00,
    min_maf = 0.05,
    cis_window = 5e5,
    min_samples = 50,
    seed = 1,
    hwe_thresh = 1e-8,
    min_n_rec = 5,

    # --- SuSiE parameters ---
    L = 10,
    standardize = FALSE,
    estimate_prior_method = "EM",
    min_abs_corr = 0.5,
    verbose = FALSE,
    max_iter = 1000,
    tol = 1e-5,

    # --- misc ---
    temp_dir = file.path(project_dir, "temp_plink_em"),
    previous_result = NULL
) {


  library(data.table)
  library(matrixStats)
  library(susieR)

  source(file.path(project_dir, "script/scan_tissue_attempt/workhorse_utils.R"),
         local = TRUE)
  source(file.path(project_dir, "script/scan_tissue_attempt/em_utils.R"),
         local = TRUE)
  em_validate_priors(tissue_priors)
  source(gene_annot_fun, local = TRUE)

  set.seed(seed)

  dir.create(
    temp_dir,
    recursive = TRUE,
    showWarnings = FALSE
  )
  plink_out_prefix <- tempfile(paste0("plink_", target_gene, "_"), tmpdir = temp_dir)

  # Always remove gene-specific PLINK intermediates, including when an
  # error occurs before the end of the gene analysis.
  on.exit(
    unlink(
      Sys.glob(
        paste0(plink_out_prefix, ".*")
      ),
      force = TRUE
    ),
    add = TRUE
  )

  # ------------------------------------------------------------
  # Import covariates
  # ------------------------------------------------------------

  cat("Importing covariate data.\n")

  cov1 <- read.table(
    subject_pheno_file,
    header = TRUE,
    sep = "\t",
    stringsAsFactors = FALSE
  )

  cov2 <- read.table(
    sample_attr_file,
    header = TRUE,
    sep = "\t",
    quote = "",
    stringsAsFactors = FALSE
  )

  cov2 <- transform(
    cov2,
    SUBJID = substr(SAMPID, 1, 10)
  )

  cov <- merge(
    cov1,
    cov2,
    by = "SUBJID"
  )

  cov <- cov[
    c(
      "SUBJID",
      "SAMPID",
      "SEX",
      "AGE",
      "SMTS",
      "SMTSD",
      "SMGEBTCHT",
      "SMAFRZE"
    )
  ]

  cov <- subset(
    cov,
    SMAFRZE == "RNASEQ"
  )

  cov <- transform(
    cov,
    SEX = SEX - 1,
    AGE = factor(AGE),
    SMTS = factor(SMTS),
    SMTSD = factor(SMTSD),
    SMGEBTCHT = factor(SMGEBTCHT),
    SMAFRZE = factor(SMAFRZE)
  )

  rownames(cov) <- cov$SAMPID

  # ------------------------------------------------------------
  # Import gene-expression data
  # ------------------------------------------------------------

  cat("Importing gene expression data.\n")

  pheno_all <- fread(
    expr_file,
    sep = "\t",
    skip = 2,
    header = TRUE,
    showProgress = TRUE
  )

  class(pheno_all) <- "data.frame"

  gene_info <- pheno_all[1:2]
  pheno_all <- pheno_all[-(1:2)]
  pheno_all <- as.matrix(pheno_all)
  pheno_all <- t(pheno_all)

  storage.mode(pheno_all) <- "double"
  colnames(pheno_all) <- gene_info$Name

  # Align expression and covariate data.
  ids <- intersect(
    cov$SAMPID,
    rownames(pheno_all)
  )

  rows1 <- match(
    ids,
    cov$SAMPID
  )

  rows2 <- match(
    ids,
    rownames(pheno_all)
  )

  cov <- cov[rows1, , drop = FALSE]
  pheno_all <- pheno_all[rows2, , drop = FALSE]

  # Extract expression for the target gene.
  j <- which(
    gene_info$Description == target_gene
  )

  if (length(j) == 0L) {
    stop("Target gene was not found: ", target_gene)
  }

  if (length(j) > 1L) {
    warning(
      "More than one expression column found for ",
      target_gene,
      "; using the first."
    )

    j <- j[1]
  }

  pheno_gene <- cbind(
    cov,
    data.frame(count = pheno_all[, j])
  )

  read_count <- rowSums(
    pheno_all,
    na.rm = TRUE
  )

  pheno_gene <- cbind(
    cov,
    data.frame(
      count = pheno_all[, j],
      total_read_count = read_count
    )
  )
  all_tissues <- levels(
    droplevels(pheno_gene$SMTS)
  )

  cat(
    "Found",
    length(all_tissues),
    "tissues for gene",
    target_gene,
    ":\n"
  )

  print(all_tissues)

  # ------------------------------------------------------------
  # Identify the cis-region
  # ------------------------------------------------------------

  genes <- get_gene_annotations(gtf_file)

  genes <- subset(
    genes,
    gene_name == target_gene
  )

  if (nrow(genes) == 0L) {
    stop(
      "No gene annotation found for: ",
      target_gene
    )
  }

  chr <- sub(
    "^chr",
    "",
    as.character(genes$chromosome[1])
  )

  if (chr == "M") {
    chr <- "MT"
  }

  if (
    length(chr) != 1L ||
    is.na(chr) ||
    !nzchar(chr)
  ) {
    stop(
      "Could not determine the chromosome for: ",
      target_gene
    )
  }

  tss <- with(
    genes[1, ],
    ifelse(strand == "+", start, end)
  )

  pos0 <- max(0, tss - cis_window)
  pos1 <- tss + cis_window

  # ------------------------------------------------------------
  # Extract cis-genotypes
  # ------------------------------------------------------------

  geno_file_raw <- paste0(
    plink_out_prefix,
    ".raw"
  )

  if (!file.exists(geno_file_raw)) {

    cat("Extracting genotype data from PLINK file.\n")

    plink_call <- sprintf(
      paste(
        "%s --bfile %s --chr %s --from-bp %d --to-bp %d",
        "--snps-only --max-alleles 2 --rm-dup exclude-all",
        "--threads 2 --memory 8000 --maf %g",
        "--recode A --out %s"
      ),
      plink_exec,
      geno_file,
      chr,
      pos0,
      pos1,
      min_maf_plink,
      plink_out_prefix
    )

    plink_status <- system(plink_call)

    if (
      plink_status != 0L ||
      !file.exists(geno_file_raw)
    ) {
      stop(
        "PLINK failed for ",
        target_gene,
        " on chromosome ",
        chr,
        " with exit status ",
        plink_status
      )
    }
  }

  geno_all <- fread(
    geno_file_raw,
    sep = "\t",
    header = TRUE
  )

  class(geno_all) <- "data.frame"

  ids <- geno_all$IID
  rownames(geno_all) <- ids

  geno_all <- geno_all[, -(1:6)]
  geno_all <- as.matrix(geno_all)
  dim(geno_all)
  storage.mode(geno_all) <- "double"

  # Remove SNPs with missing genotypes.
  keep <- colSums(is.na(geno_all)) == 0

  geno_all <- geno_all[
    ,
    keep,
    drop = FALSE
  ]

  # Remove SNPs that do not vary.
  keep <- colSds(geno_all) > 0

  geno_all <- geno_all[
    ,
    keep,
    drop = FALSE
  ]

  # ------------------------------------------------------------
  # Genotype QC functions
  # ------------------------------------------------------------




  geno_all<- qc_filter_geno(
    X = geno_all,
    hwe_thresh = hwe_thresh,
    maf_min = min_maf
  )$X

  # ------------------------------------------------------------
  # Construct additive, recessive and dominant predictors
  # ------------------------------------------------------------



  geno_mix_parts <- recode_snp_matrix(
    geno_all
  )

  base_snp_names <- colnames(geno_all)

  # Give every mixed predictor a unique name.
  colnames(geno_mix_parts$additive) <- paste0(
    base_snp_names,
    "__additive"
  )

  colnames(geno_mix_parts$recessive) <- paste0(
    base_snp_names,
    "__recessive"
  )

  colnames(geno_mix_parts$dominant) <- paste0(
    base_snp_names,
    "__dominant"
  )

  geno_mix_all <- cbind(
    geno_mix_parts$additive,
    geno_mix_parts$recessive,
    geno_mix_parts$dominant
  )

  # Map every mixed predictor to its biological SNP and coding.
  geno_mix_snp_all <- rep(
    base_snp_names,
    times = 3L
  )

  geno_mix_coding_all <- rep(
    c(
      "additive",
      "recessive",
      "dominant"
    ),
    each = length(base_snp_names)
  )

  # Convert to double without losing names.
  storage.mode(geno_all) <- "double"
  storage.mode(geno_mix_all) <- "double"

  analyze_tissue <- function(target_tissue) {

    cat("\n=====================================\n")
    cat("Tissue:", target_tissue, "\n")
    cat("=====================================\n")
    pheno <- subset(
      pheno_gene,
      SMTS == target_tissue
    )

    ids <- intersect(
      pheno$SUBJID,
      rownames(geno_all)
    )

    rows <- match(
      ids,
      pheno$SUBJID
    )

    # Subset and order the phenotype data before normalization.
    pheno <- pheno[
      rows,
      ,
      drop = FALSE
    ]

    stopifnot(
      identical(
        as.character(pheno$SUBJID),
        as.character(ids)
      )
    )

    # Remove samples with invalid expression or library-size values.
    keep_sample <- (
      is.finite(pheno$count) &
        is.finite(pheno$total_read_count) &
        pheno$total_read_count > 0 &
        !is.na(pheno$SEX)
    )

    pheno <- pheno[
      keep_sample,
      ,
      drop = FALSE
    ]

    # Update IDs after sample filtering so genotypes remain aligned.
    ids <- as.character(
      pheno$SUBJID
    )

    # Skip before normalization and matrix operations if too few matched
    # samples remain in this tissue.
    if (nrow(pheno) < min_samples) {

      cat(
        "Skipping",
        target_tissue,
        "- only",
        nrow(pheno),
        "samples.\n"
      )

      return(NULL)
    }

    median_read <- median(
      pheno$count
    )

    mean_read <- mean(
      pheno$count
    )

    pheno <- transform(
      pheno,
      SMGEBTCHT = factor(SMGEBTCHT)
    )

    # Library-size normalization within the tissue.
    pheno$library_size_factor <- (
      pheno$total_read_count /
        mean(pheno$total_read_count)
    )

    pheno$normalized_expression <- log1p(
      pheno$count /
        pheno$library_size_factor
    )
    x=pheno$normalized_expression
    pheno$normalized_expression =qnorm((rank(x,na.last="keep")-0.5)/sum(!is.na(x)))
    # Residualize normalized expression on sex.
    pheno$y <- resid(
      lm(
        normalized_expression ~ SEX,
        data = pheno
      )
    )
    x=pheno$y
    pheno$y =qnorm((rank(x,na.last="keep")-0.5)/sum(!is.na(x)))

    y_variance <- var(
      pheno$y
    )

    if (
      !is.finite(y_variance) ||
      y_variance <= 1e-12
    ) {

      cat(
        "Skipping",
        target_tissue,
        "- residual phenotype variance is zero.\n"
      )

      return(NULL)
    }


    geno_mix <- geno_mix_all[
      ids,
      ,
      drop = FALSE
    ]

    # ----------------------------------------------------------
    # Tissue-specific predictor filtering
    # ----------------------------------------------------------

    # Filter the mixed matrix and its predictor maps together.
    keep_mix <- (
      colSums(geno_mix) >= min_n_rec &
        matrixStats::colSds(geno_mix) > 0
    )

    n_add_rm <- sum(
      !keep_mix & geno_mix_coding_all == "additive"
    )

    n_rec_rm <- sum(
      !keep_mix &
        geno_mix_coding_all == "recessive"
    )

    n_dom_rm <- sum(
      !keep_mix &
        geno_mix_coding_all == "dominant"
    )

    geno_mix <- geno_mix[
      ,
      keep_mix,
      drop = FALSE
    ]

    mix_snp_names <- geno_mix_snp_all[
      keep_mix
    ]

    mix_coding <- geno_mix_coding_all[
      keep_mix
    ]

    mix_predictor_names <- colnames(
      geno_mix
    )

    if (ncol(geno_mix) == 0L) {
      cat("Skipping", target_tissue, "- no predictors remained after filtering.\n")
      return(NULL)
    }

    mix_coding_prior <- em_prior_for_tissue(tissue_priors, target_tissue)
    weighted_mix_prior_weights <- em_predictor_weights(
      mix_coding, mix_coding_prior, mix_predictor_names
    )

    mix_predictor_map <- data.frame(
      predictor_index = seq_len(ncol(geno_mix)),
      predictor_name = mix_predictor_names,
      snp = mix_snp_names,
      coding = mix_coding,
      stringsAsFactors = FALSE
    )

    stopifnot(identical(as.character(pheno$SUBJID), rownames(geno_mix)))
    cat("Running weighted SuSiE-mix for", target_tissue, "\n")
    set.seed(seed)

    previous_tissue <- previous_result[[target_tissue]]
    previous_fit <- previous_tissue[["weighted_fit_mix"]]
    # Initializing from the original scan must use the unweighted fit, which
    # supplied the initial posterior statistics, not its other weighted fit.
    source_fit <- unique(tissue_priors$source_fit)
    if (identical(source_fit, "susie_mix")) previous_fit <- previous_tissue[["susie_mix"]]
    initialization <- em_susie_initialization(previous_fit, mix_predictor_names, L, var(pheno$y))

    weighted_fit_mix <- susie(
      geno_mix,
      pheno$y,
      prior_weights = weighted_mix_prior_weights,
      L = L,
      standardize = standardize,
      estimate_prior_method = estimate_prior_method,
      s_init = initialization$s_init,
      scaled_prior_variance = if (is.null(initialization)) 0.2 else initialization$scaled_prior_variance,
      residual_variance = initialization$residual_variance,
      max_iter = max_iter,
      tol = tol,
      min_abs_corr = min_abs_corr,
      verbose = verbose
    )
    if (!isTRUE(all.equal(unname(weighted_fit_mix$pi), unname(weighted_mix_prior_weights),
                         tolerance = 1e-12))) {
      em_stop_fit("SuSiE did not retain the newly estimated coding prior weights.")
    }

    weighted_fit_mix_lead_snp_tss_distance <- (
      get_cs_lead_tss_distance(
        fit = weighted_fit_mix,
        predictor_map = mix_predictor_map,
        tss = tss
      )
    )
    # ----------------------------------------------------------
    # Store results and predictor mappings
    # ----------------------------------------------------------

    list(
      weighted_fit_mix = weighted_fit_mix,

      # Lead biological SNP and signed distance to the TSS.
      weighted_fit_mix_lead_snp_tss_distance =
        weighted_fit_mix_lead_snp_tss_distance,

      # Predictor maps.
      mix_predictor_map = mix_predictor_map,

      mix_snp_names = mix_snp_names,
      mix_coding = mix_coding,
      mix_predictor_names = mix_predictor_names,
      mix_coding_prior = mix_coding_prior,
      weighted_mix_prior_weights = weighted_mix_prior_weights,
      em_warm_started = !is.null(initialization),

      n_SNP = length(unique(mix_snp_names)),
      n_mix_predictor = ncol(geno_mix),
      n_add_rm = n_add_rm,
      n_rec_rm = n_rec_rm,
      n_dom_rm = n_dom_rm,

      n_ind = length(pheno$y),
      mean_phe = mean(pheno$y),
      median_phe = median(pheno$y),
      median_read = median_read,
      mean_read = mean_read
    )
  }

  fits <- list()
  tissue_errors <- list()

  for (target_tissue in all_tissues) {

    tissue_result <- tryCatch(
      analyze_tissue(
        target_tissue
      ),
      error = function(e) e
    )

    if (inherits(tissue_result, "error")) {

      if (inherits(tissue_result, "em_fit_error")) stop(tissue_result)

      error_message <- conditionMessage(
        tissue_result
      )

      message(
        "ERROR [",
        target_gene,
        " / ",
        target_tissue,
        "]: ",
        error_message
      )

      tissue_errors[[target_tissue]] <- error_message
      next
    }

    if (is.null(tissue_result)) {
      next
    }

    fits[[target_tissue]] <- tissue_result
  }

  # Preserve tissue-level failures for auditing without changing the
  # existing list-of-successful-tissues result structure.
  attr(fits, "tissue_errors") <- tissue_errors

  fits
}
