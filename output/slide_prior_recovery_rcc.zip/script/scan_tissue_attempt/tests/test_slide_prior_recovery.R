# Base-R tests: real metadata/checkpoint handling, no cluster or GTEx data needed.
repo <- normalizePath(".", winslash = "/")
for (f in c("em_utils.R", "slide_prior_em_utils.R", "slide_prior_recovery.R", "prepare_slide_prior_em_iteration.R"))
  source(file.path(repo, "script/scan_tissue_attempt", f))
fails <- function(expr, pattern) {
  e <- tryCatch({force(expr); NULL}, error = identity)
  stopifnot(inherits(e, "error"), grepl(pattern, conditionMessage(e)))
}
dir.create(file.path(repo, "tmp"), showWarnings = FALSE)
root <- tempfile("slide_recovery_", tmpdir = file.path(repo, "tmp")); dir.create(root)
scripts <- file.path(root, "script/scan_tissue_attempt"); dir.create(scripts, recursive = TRUE)
file.copy(file.path(repo, "script/scan_tissue_attempt/slide_prior_recovery.R"), scripts)
d <- file.path(root, "results_slide_prior_em/iteration_000")
dir.create(file.path(d, "results"), recursive = TRUE)
dir.create(file.path(d, "completed"))
genes <- sprintf("G%03d", 1:23)
manifest <- data.frame(chunk = rep(1:2, c(12, 11)), gene = genes)
w <- matrix(1/17, 2, 17, dimnames = list(NULL, spe_columns()))
priors <- data.frame(iteration = 0L, source_iteration = -1L, tissue = c("Brain", "Liver"), w,
                     n_fits = 0L, n_active = 0L, free_mass = 0, prior_max_change = 0,
                     m_step_q_gain = 0, source_elbo = NA_real_,
                     update_method = "slider_prior_active_counts_v1", created_at = "fixture")
write.csv(priors, file.path(d, "priors.csv"), row.names = FALSE)
write.csv(priors, file.path(root, "results_slide_prior_em/prior_history.csv"), row.names = FALSE)
write.csv(manifest, file.path(d, "manifest.csv"), row.names = FALSE)
write.csv(data.frame(delta = spe_grid()), file.path(d, "grid.csv"), row.names = FALSE)
saveRDS(c(spe_settings(), list(package_version = "fixture")), file.path(d, "settings.rds"))
saveRDS(list(chunk = 1L), file.path(d, "completed/chunk_001.done"))
ctx <- sre_context(root, d)
frozen_files <- c(file.path(d, names(ctx$frozen)), file.path(d, "completed/chunk_001.done"))
hashes <- tools::md5sum(frozen_files)
make_fit <- function(prior = rep(1/17, 17), converged = TRUE) {
  L <- 2L
  a <- matrix(rep(c(.8, .2), each = L), L, 2)
  joint <- array(0, c(L, 2L, 17L))
  for (l in 1:L) {joint[l, 1, ] <- .8 * prior; joint[l, 2, 9] <- .2}
  counts <- matrix(0, L, 17); counts[1, ] <- .8 * prior
  structure(list(alpha = a, alpha_delta = joint, delta_prior_counts = counts,
                 delta_forced = c(FALSE, TRUE), input_p = 2L, delta_grid = spe_grid(),
                 delta_prior = prior, V = c(1, 0), converged = converged, elbo = -100),
            class = c("susie_slide", "susie"))
}
make_out <- function(converged = TRUE) {
  x <- list(Brain = list(fit_slide_prior = make_fit(converged = converged)))
  attr(x, "em_iteration") <- 0L
  x
}
save_gene <- function(g, x) saveRDS(x, sre_result(ctx, g))
save_gene("G001", make_out())
error_out <- structure(list(gene = "G002", error = "PLINK failed: Cannot allocate memory"), em_iteration = 0L)
save_gene("G002", error_out)
save_gene("G003", structure(list(), em_iteration = 0L))
partial <- make_out(); attr(partial, "tissue_errors") <- list(Liver = "Allocation failure")
save_gene("G004", partial)
save_gene("G005", structure(list(error = "Unknown gene"), em_iteration = 0L))
save_gene("G006", make_out(FALSE))
bad <- make_out(); bad$Brain$fit_slide_prior$delta_prior <- c(1, rep(0, 16)); save_gene("G007", bad)
writeLines("corrupt", sre_result(ctx, "G008"))
good_hash <- tools::md5sum(sre_result(ctx, "G001"))
audit <- sre_audit(ctx)
stopifnot(sum(sre_ready(audit$status)) == 2L, audit$status[2] == "retry",
          audit$status[4] == "retry", audit$status[6] == "retry")
plan <- sre_load(ctx)$plan
stopifnot(identical(plan$gene, genes), identical(as.integer(table(plan$task)), c(10L, 10L, 3L)))
full_plan <- data.frame(task = ceiling(seq_len(18468)/10), gene = seq_len(18468))
stopifnot(length(unique(full_plan$task)) == 1847L, max(table(full_plan$task)) == 10L)
batch <- sre_plan_batch(ctx, 1L, genes_per_task = 10L)
selected <- sre_task_genes(ctx, batch$path, 1L)
stopifnot(length(selected) == 8L, "G002" %in% selected, !"G001" %in% selected)
fails(sre_task_genes(ctx, batch$path, 2L), "Invalid batch")
# Simulate the old on-disk format: changing the cap must not invalidate it.
old_settings <- readRDS(file.path(batch$path, "settings.rds"))
old_settings$genes_per_task <- NULL
saveRDS(old_settings, file.path(batch$path, "settings.rds"))
preserved <- c(file.path(ctx$root, c("state.rds", "manifest.csv")),
               file.path(batch$path, c("manifest.csv", "settings.rds")))
preserved_hash <- tools::md5sum(preserved)
needed <- audit$gene[!sre_ready(audit$status)]
for (cap in c(4L, 5L)) {
  smaller <- sre_plan_batch(ctx, 298L, genes_per_task = cap)
  work <- read.csv(file.path(smaller$path, "manifest.csv"))
  stopifnot(setequal(work$gene, needed), !anyDuplicated(work$gene),
            max(table(work$array_task)) <= cap,
            identical(sort(unique(work$array_task)), seq_len(smaller$tasks)))
  for (task in seq_len(smaller$tasks))
    stopifnot(identical(sre_task_genes(ctx, smaller$path, task), work$gene[work$array_task == task]))
}
bounded <- sre_plan_batch(ctx, 2L) # Four genes by default; capacity applies after splitting.
work <- read.csv(file.path(bounded$path, "manifest.csv"))
stopifnot(bounded$tasks == 2L, nrow(work) == 8L, max(table(work$array_task)) == 4L,
          identical(preserved_hash, tools::md5sum(preserved)),
          identical(sre_task_genes(ctx, batch$path, 1L), selected))
fails(sre_plan_batch(ctx, 1L, genes_per_task = 0), "genes_per_task")
fails(sre_plan_batch(ctx, 1L, genes_per_task = 16), "genes_per_task")
# Workers enforce the cap frozen in their batch, not a later environment setting.
bounded_settings <- readRDS(file.path(bounded$path, "settings.rds"))
bad_cap <- bounded_settings; bad_cap$genes_per_task <- 3L
saveRDS(bad_cap, file.path(bounded$path, "settings.rds"))
fails(sre_task_genes(ctx, bounded$path, 1L), "Invalid batch gene assignment")
saveRDS(bounded_settings, file.path(bounded$path, "settings.rds"))
fails(sre_audit(ctx, 16L), "genes_per_task")
fails(sre_audit(ctx, 15L), "settings differ")
fails(sre_verify(ctx), "unresolved")
stopifnot(!file.exists(file.path(root, "results_slide_prior_em/objective_history.csv")))
fails(sre_require_complete(root, d), "unfinished")
fails(spe_prepare_iteration(root, "resume", package_version = "fixture"), "recovery-managed")

# Targeted pilots respect the frozen assignment, and launch failures cannot loop.
pilot <- sre_plan_batch(ctx, 5L, pilot_genes = c("G001", "G011", "G023"))
stopifnot(pilot$tasks == 2L,
          identical(sre_task_genes(ctx, pilot$path, 1L), "G011"),
          identical(sre_task_genes(ctx, pilot$path, 2L), "G023"),
          sre_plan_batch(ctx, 5L, pilot_genes = "G001")$status == "pilot_empty")
fails(sre_plan_batch(ctx, 5L, pilot_genes = "UNKNOWN"), "Pilot gene list")
writeLines(pilot$path, file.path(ctx$root, "last_batch.txt"))
stopifnot(sre_plan_batch(ctx, 5L, automatic = TRUE)$status == "blocked",
          sre_plan_batch(ctx, 5L)$status == "batch")
unlink(file.path(ctx$root, "last_batch.txt"))

# Rolling refills retain every gene assigned to an active task, even before
# its first R process starts. Completed tasks in that same array free capacity.
queue_file <- file.path(root, "queue.txt")
writeLines("9100", file.path(bounded$path, "array_job_id.txt"))
writeLines("9100_1|9100|slide_recover_worker", queue_file)
live_genes <- sre_task_genes(ctx, bounded$path, 1L)
live <- sre_queue_work(ctx, queue_file)
stopifnot(setequal(live$genes, live_genes), live$tasks == 1L)
rolling <- sre_plan_batch(ctx, 2L, automatic = TRUE, queue_file = queue_file)
rolling_work <- read.csv(file.path(rolling$path, "manifest.csv"))
stopifnot(!any(rolling_work$gene %in% live_genes),
          any(rolling_work$gene %in% sre_task_genes(ctx, bounded$path, 2L)),
          sre_plan_batch(ctx, 2L, queue_file = queue_file, refill_below = 1L)$status == "waiting",
          sre_plan_batch(ctx, 0L, queue_file = queue_file)$status == "waiting")
# Pending tasks with no attempts are not treated as a launch failure.
writeLines(bounded$path, file.path(ctx$root, "last_batch.txt"))
stopifnot(sre_plan_batch(ctx, 2L, automatic = TRUE, queue_file = queue_file)$status == "batch")
unlink(file.path(ctx$root, "last_batch.txt"))
# Adopt a second array and reject overlapping assignments or untracked workers.
writeLines("9200", file.path(pilot$path, "array_job_id.txt"))
writeLines(c("9100_1|9100|slide_recover_worker", "9200_1|9200|slide_recover_worker"), queue_file)
stopifnot(sre_queue_work(ctx, queue_file)$tasks == 2L,
          setequal(sre_queue_work(ctx, queue_file)$genes, c(live_genes, "G011")))
writeLines("9300", file.path(smaller$path, "array_job_id.txt"))
writeLines(c("9100_1|9100|slide_recover_worker", "9300_1|9300|slide_recover_worker"), queue_file)
fails(sre_queue_work(ctx, queue_file), "multiple active tasks")
unlink(file.path(smaller$path, "array_job_id.txt"))
writeLines("9999_1|9999|slide_recover_worker", queue_file)
fails(sre_queue_work(ctx, queue_file), "Untracked recovery worker")
writeLines("9100_299|9100|slide_recover_worker", queue_file)
fails(sre_queue_work(ctx, queue_file), "Unknown active array task")
writeLines("9100_1|9100|slide_recover_worker|extra", queue_file)
fails(sre_queue_work(ctx, queue_file), "Invalid scheduler queue")
writeLines("9100_1|9100|slide_recover_worker", queue_file)
changed_batch <- bounded_settings; changed_batch$manifest_md5 <- "changed"
saveRDS(changed_batch, file.path(bounded$path, "settings.rds"))
fails(sre_queue_work(ctx, queue_file), "Batch manifest changed")
saveRDS(bounded_settings, file.path(bounded$path, "settings.rds"))
# A finished older batch with no worker progress stops automatic replenishment,
# even while a newer batch remains active.
stopifnot(sre_plan_batch(ctx, 2L, automatic = TRUE, queue_file = queue_file)$status == "blocked")
unlink(file.path(pilot$path, "array_job_id.txt"))
# The currently running final attempt must not exhaust the budget prematurely.
audit_before_rolling <- read.csv(file.path(ctx$root, "audit.csv"))
em_atomic_write(list(gene = "G002", attempt = 3L, frozen = ctx$frozen,
                    error = "Interrupted before receipt"), sre_attempt_file(ctx, "G002"))
stopifnot(sre_plan_batch(ctx, 2L, automatic = TRUE, queue_file = queue_file)$status == "batch")
writeLines(character(), queue_file)
stopifnot(sre_plan_batch(ctx, 2L, automatic = TRUE, queue_file = queue_file)$status == "blocked")
unlink(sre_attempt_file(ctx, "G002"))
em_atomic_write(audit_before_rolling, file.path(ctx$root, "audit.csv"), csv = TRUE)
unlink(file.path(bounded$path, "array_job_id.txt"))

# Node failures/requeues consume attempts. A reviewed allowance preserves that
# history and permits exactly one further attempt, for exactly one gene.
interrupted <- list(gene = "G023", attempt = 3L, frozen = ctx$frozen,
                    started_at = "2026-10-11 05:49:58 UTC", error = "Interrupted before receipt")
em_atomic_write(interrupted, sre_attempt_file(ctx, "G023"))
stopifnot(sre_plan_batch(ctx, 298)$status == "blocked")
fails(sre_grant_interrupted_retry(ctx, "UNKNOWN", 3L, "Node failure"), "active manifest")
fails(sre_grant_interrupted_retry(ctx, "G023", 2L, "Node failure"), "original retry limit")
fails(sre_grant_interrupted_retry(ctx, "G023", 3L, ""), "accounting evidence")
changed <- interrupted; changed$attempt <- 2L
saveRDS(changed, sre_attempt_file(ctx, "G023"))
fails(sre_grant_interrupted_retry(ctx, "G023", 3L, "Node failure"), "count changed")
changed <- interrupted; changed$error <- "Unconverged fit"; changed$finished_at <- "fixture"
saveRDS(changed, sre_attempt_file(ctx, "G023"))
fails(sre_grant_interrupted_retry(ctx, "G023", 3L, "Node failure"), "interrupted attempt")
saveRDS(interrupted, sre_attempt_file(ctx, "G023"))
allowance <- sre_grant_interrupted_retry(ctx, "G023", 3L, "Reviewed three NODE_FAIL records")
allowance_file <- file.path(ctx$root, "retry_allowances/G023.rds")
allowance_hash <- tools::md5sum(allowance_file)
stopifnot(identical(readRDS(sre_attempt_file(ctx, "G023")), interrupted),
          identical(allowance$previous_receipt, interrupted),
          identical(unname(sre_attempt_limits(ctx, sre_load(ctx)$state, c("G023", "G022"))), c(4L, 3L)),
          identical(preserved_hash, tools::md5sum(preserved)))
sre_grant_interrupted_retry(ctx, "G023", 3L, "Reviewed three NODE_FAIL records")
stopifnot(identical(allowance_hash, tools::md5sum(allowance_file)))
fails(sre_grant_interrupted_retry(ctx, "G023", 3L, "Different review"), "different retry review")
bad_allowance <- allowance; bad_allowance$frozen <- "different"
saveRDS(bad_allowance, allowance_file)
fails(sre_plan_batch(ctx, 298), "Invalid reviewed retry allowance")
saveRDS(allowance, allowance_file)
retry_batch <- sre_plan_batch(ctx, 1L, pilot_genes = "G023")
stopifnot(identical(sre_task_genes(ctx, retry_batch$path, 1L), "G023"),
          sre_plan_batch(ctx, 298)$status == "batch")
fails(sre_run_gene(ctx, "G023", function(...) stop("Fixture failed retry")), "Fixture failed retry")
stopifnot(readRDS(sre_attempt_file(ctx, "G023"))$attempt == 4L,
          sre_plan_batch(ctx, 298)$status == "blocked")
# Repeating the repair command must not authorize a fifth attempt.
sre_grant_interrupted_retry(ctx, "G023", 3L, "Reviewed three NODE_FAIL records")
fails(sre_run_gene(ctx, "G023", function(...) stop("Must not run")), "budget exhausted")
fails(sre_grant_interrupted_retry(ctx, "G023", 4L, "Another failure"), "original retry limit")
save_gene("G023", make_out())
stopifnot(sre_refresh(ctx)$status[23] == "valid",
          identical(hashes, tools::md5sum(frozen_files)))
# Successful fourth attempts are reused without a fifth fit or cohort change.
interrupted$gene <- "G022"
saveRDS(interrupted, sre_attempt_file(ctx, "G022"))
sre_grant_interrupted_retry(ctx, "G022", 3L, "Reviewed node failure")
sre_run_gene(ctx, "G022", function(...) make_out())
sre_run_gene(ctx, "G022", function(...) stop("Completed result must be reused"))
stopifnot(readRDS(sre_attempt_file(ctx, "G022"))$attempt == 4L)

# A reviewed error cannot conceal a malformed successful tissue posterior.
invalid <- partial; invalid$Brain$fit_slide_prior$alpha_delta[1, 1, 1] <- -1
save_gene("G004", invalid)
write.csv(data.frame(gene = "G004", result_md5 = unname(tools::md5sum(sre_result(ctx, "G004"))),
                     reason = "Fixture review"), file.path(ctx$root, "reviewed_exclusions.csv"), row.names = FALSE)
stopifnot(sre_inspect(ctx, "G004")$status == "retry")
save_gene("G004", partial)
unlink(file.path(ctx$root, "reviewed_exclusions.csv"))

calls <- character()
fake <- function(target_gene, ...) {calls <<- c(calls, target_gene); make_out()}
sre_run_gene(ctx, "G001", fake)
stopifnot(!length(calls), identical(good_hash, tools::md5sum(sre_result(ctx, "G001"))))
fails(sre_run_gene(ctx, "G002", function(...) {warning("system call failed: Cannot allocate memory"); stop("PLINK failed")}), "PLINK failed")
a <- readRDS(sre_attempt_file(ctx, "G002"))
stopifnot(a$attempt == 1L, grepl("Cannot allocate", a$error), identical(readRDS(sre_result(ctx, "G002")), error_out))
sre_run_gene(ctx, "G002", fake)
sre_run_gene(ctx, "G002", fake)
stopifnot(readRDS(sre_attempt_file(ctx, "G002"))$attempt == 2L, sum(calls == "G002") == 1L)
# Missing output gets an inspectable error, but never a completion status.
for (g in c("G020", "G021"))
  fails(sre_run_gene(ctx, g, function(...) stop("Cannot allocate memory")), "Cannot allocate")
stopifnot(file.exists(sre_result(ctx, "G020")), sre_inspect(ctx, "G020")$status == "retry",
          sre_plan_batch(ctx, 2L, automatic = TRUE)$status == "blocked",
          sre_plan_batch(ctx, 2L)$status == "batch")
for (g in c("G020", "G021")) sre_run_gene(ctx, g, fake)
# Corrupt or mismatched receipts must be rejected, including cached successes.
invisible(sre_refresh(ctx))
receipt <- readRDS(sre_attempt_file(ctx, "G002"))
writeLines("corrupt", sre_attempt_file(ctx, "G002"))
fails(sre_refresh(ctx), "Unreadable attempt")
wrong <- receipt; wrong$frozen <- "different"
saveRDS(wrong, sre_attempt_file(ctx, "G002"))
fails(sre_refresh(ctx), "different settings")
saveRDS(receipt, sre_attempt_file(ctx, "G002"))
fails(sre_run_gene(ctx, "G006", function(...) make_out(FALSE)), "Unconverged")
sre_run_gene(ctx, "G006", fake)
# A killed process consumes an attempt; an output saved before its receipt is recovered.
em_atomic_write(list(attempt = 1L, frozen = ctx$frozen, error = "Interrupted"), sre_attempt_file(ctx, "G009"))
save_gene("G009", make_out())
audit <- sre_refresh(ctx)
stopifnot(audit$status[audit$gene == "G009"] == "valid")
# Explicit approval is bound to the exact error output; it can resolve an exhausted retry.
for (i in 1:3) fails(sre_run_gene(ctx, "G005", function(...) stop("Unknown gene")), "Unknown gene")
stopifnot(sre_plan_batch(ctx, 298)$status == "blocked")
write.csv(data.frame(gene = "G005", result_md5 = unname(tools::md5sum(sre_result(ctx, "G005"))),
                     reason = "Fixture: reviewed missing annotation"),
          file.path(ctx$root, "reviewed_exclusions.csv"), row.names = FALSE)
audit <- sre_refresh(ctx)
stopifnot(audit$status[audit$gene == "G005"] == "reviewed_exclusion")
# Several small waves cover every unresolved gene once, with successful receipts
# and retry budgets carried forward when changing from four to five genes/task.
remaining <- audit$gene[!sre_ready(audit$status)]
scheduled <- character()
wave <- 0L
repeat {
  wave <- wave + 1L
  cap <- if (wave %% 2L) 4L else 5L
  small <- sre_plan_batch(ctx, 1L, genes_per_task = cap)
  if (small$status == "verify") break
  stopifnot(small$status == "batch", small$tasks == 1L)
  next_genes <- sre_task_genes(ctx, small$path, 1L)
  stopifnot(length(next_genes) <= cap, !any(next_genes %in% scheduled))
  for (g in next_genes) sre_run_gene(ctx, g, fake)
  scheduled <- c(scheduled, next_genes)
  stopifnot(wave <= length(genes))
}
stopifnot(setequal(scheduled, remaining),
          readRDS(sre_attempt_file(ctx, "G002"))$attempt == 2L,
          identical(preserved_hash, tools::md5sum(preserved)))
stopifnot(identical(hashes, tools::md5sum(frozen_files)))
sre_verify(ctx)
# Even with every result ready, an active task prevents the EM boundary.
audit_before_live_boundary <- read.csv(file.path(ctx$root, "audit.csv"))
writeLines("9100", file.path(bounded$path, "array_job_id.txt"))
writeLines("9100_1|9100|slide_recover_worker", queue_file)
stopifnot(sre_plan_batch(ctx, 298L, queue_file = queue_file)$status == "waiting")
writeLines(character(), queue_file)
stopifnot(sre_plan_batch(ctx, 298L, queue_file = queue_file)$status == "verify")
unlink(file.path(bounded$path, "array_job_id.txt"))
em_atomic_write(audit_before_live_boundary, file.path(ctx$root, "audit.csv"), csv = TRUE)
# Scope is based on annotation, not failed-job text: it excludes missing genes,
# successful fits and exhausted failures alike, while retaining autosomal errors.
annotations <- data.frame(gene_name = genes, chromosome = rep("chr1", length(genes)))
annotations$chromosome[10:16] <- c("chrX", "chrY", "chrMT", "chrM", "23", "24", "26")
annotations <- rbind(annotations, data.frame(gene_name = "G001", chromosome = "X"))
fails(sre_exclude_sex_mt(ctx, annotations[1:3, ]), "Cannot assign chromosomes")
scope_file <- file.path(root, "results_slide_prior_em/chromosome_scope.rds")
stopifnot(!file.exists(scope_file))
unlink(sre_result(ctx, "G010"))
excluded_hash <- tools::md5sum(sre_result(ctx, "G011"))
save_gene("G012", structure(list(error = "PLINK failed on MT"), em_iteration = 0L))
save_gene("G017", structure(list(error = "Autosomal failure"), em_iteration = 0L))
writeLines("corrupt receipt on an excluded chromosome", sre_attempt_file(ctx, "G013"))
auto_attempt <- readRDS(sre_attempt_file(ctx, "G002"))$attempt
ctx <- sre_exclude_sex_mt(ctx, annotations)
scope_hash <- tools::md5sum(scope_file)
stopifnot(identical(ctx$scope$excluded, genes[10:16]),
          sre_inspect(ctx, "G001")$status == "valid",
          sre_inspect(ctx, "G010")$status == "scope_excluded",
          sre_inspect(ctx, "G012")$status == "scope_excluded",
          sre_inspect(ctx, "G017")$status == "retry",
          readRDS(sre_attempt_file(ctx, "G002"))$attempt == auto_attempt)
fails(sre_task_genes(ctx, batch$path, 1L), "Batch manifest changed")
fails(sre_require_complete(root, d), "unfinished")
scope_batch <- sre_plan_batch(ctx, 298L)
scope_work <- read.csv(file.path(scope_batch$path, "manifest.csv"))
stopifnot(!any(scope_work$gene %in% genes[10:16]))
for (g in genes[10:16]) sre_run_gene(ctx, g, function(...) stop("Excluded gene must not fit"))
stopifnot(!file.exists(sre_result(ctx, "G010")),
          identical(excluded_hash, tools::md5sum(sre_result(ctx, "G011"))))
ctx <- sre_exclude_sex_mt(ctx, annotations)
stopifnot(identical(scope_hash, tools::md5sum(scope_file)),
          identical(hashes, tools::md5sum(frozen_files)))
sre_run_gene(ctx, "G017", fake)
# Resume an activation interrupted after saving the policy but before its state.
active_state <- readRDS(file.path(ctx$root, "state.rds"))
interrupted_state <- active_state; interrupted_state$scope_md5 <- NULL
saveRDS(interrupted_state, file.path(ctx$root, "state.rds"))
fails(sre_context(root, d), "Chromosome scope changed")
ctx <- sre_exclude_sex_mt(sre_context(root, d, allow_scope_adoption = TRUE))
scope_backup <- file.path(root, "scope_backup.rds")
invisible(file.copy(scope_file, scope_backup))
unlink(scope_file)
fails(sre_context(root, d), "Chromosome scope changed")
invisible(file.copy(scope_backup, scope_file))
tampered <- readRDS(scope_file); tampered$genes$chromosome[1] <- "X"
saveRDS(tampered, scope_file)
fails(sre_context(root, d), "Chromosome scope changed")
invisible(file.copy(scope_backup, scope_file, overwrite = TRUE))
sre_verify(ctx)
sre_require_complete(root, d)
objective <- read.csv(file.path(root, "results_slide_prior_em/objective_history.csv"))
stopifnot(nrow(objective) == 3L, objective$iteration[1] == 0L,
          objective$n_fits[objective$level == "overall"] == 14L,
          objective$elbo[objective$level == "overall"] == -1400)
stopifnot(file.exists(file.path(ctx$root, "COMPLETE.rds")), all(sre_ready(sre_refresh(ctx)$status)))
# Refresh changes audit columns; recertification is required before a new update.
sre_verify(ctx)
next_iteration <- spe_prepare_iteration(root, "new", package_version = "fixture")
stopifnot(basename(next_iteration$iteration_dir) == "iteration_001")
updated <- read.csv(file.path(next_iteration$iteration_dir, "priors.csv"))
stopifnot(sum(updated$n_fits) == 14L,
          !any(sub("\\.rds$", "", basename(sre_pool_files(ctx))) %in% genes[10:16]))
ctx1 <- sre_context(root, next_iteration$iteration_dir)
sre_audit(ctx1)
fails(sre_exclude_sex_mt(ctx1, annotations), "before learned-prior updates")
sre_run_gene(ctx1, "G010", function(...) stop("Excluded genes must stay excluded in later iterations"))
stopifnot(sre_inspect(ctx1, "G010")$status == "scope_excluded")
sre_run_gene(ctx1, "G005", function(...) stop("Must inherit reviewed cohort exclusion"))
stopifnot(sre_inspect(ctx1, "G005")$status == "reviewed_exclusion")
fails(sre_run_gene(ctx1, "G001", function(...) list()), "cohort changed")
# The certificate cannot hide corruption of a previously validated fit.
writeLines("now corrupt", sre_result(ctx, "G001"))
fails(sre_require_complete(root, d), "unresolved")
# Neither re-audit nor a worker is allowed to silently bless manifest tampering.
write.csv(data.frame(task = 1, gene = "G001"), file.path(ctx$root, "manifest.csv"), row.names = FALSE)
fails(sre_audit(ctx), "manifest.*changed")
cat("PASS: recovery audit, configurable batch caps, legacy batches, multi-wave recovery, retries, frozen chromosome scope, excluded missing/successful/failed genes, pooling, warm-start cohort and completion gates.\n")
stopifnot(identical(dirname(normalizePath(root, winslash = "/")), paste0(repo, "/tmp")))
unlink(root, recursive = TRUE)
