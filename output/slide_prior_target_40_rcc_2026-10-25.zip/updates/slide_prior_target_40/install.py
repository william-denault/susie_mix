"""Atomically install target controls. Does not submit, cancel or hold jobs."""
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile

def digest(data):
    return hashlib.sha256(data.decode("utf-8-sig").replace("\r\n", "\n").encode("utf-8")).hexdigest()

def main():
    if len(sys.argv) != 2:
        raise RuntimeError("Usage: python3 install.py RCC_PROJECT_DIRECTORY")
    project = Path(sys.argv[1]).resolve()
    here = Path(__file__).resolve().parent
    manifest = json.loads((here / "manifest.json").read_text())
    if not (project / "results_slide_prior_em/prior_history.csv").is_file():
        raise RuntimeError("No existing slider EM run at this project path")
    prepared = []
    # Validate every input before replacing any installed file. Order is helper
    # first, then the CLI that loads it; each replacement is a single rename.
    for entry in manifest:
        destination = (project / entry["path"]).resolve()
        if project not in destination.parents:
            raise RuntimeError("Invalid destination")
        content = (here / "payload" / entry["path"]).read_bytes()
        if digest(content) != entry["sha256"]:
            raise RuntimeError("Payload checksum mismatch: " + entry["path"])
        if destination.exists():
            current = destination.read_bytes()
            if digest(current) not in entry["accepted"]:
                raise RuntimeError("Installed file differs from the reviewed version: " + entry["path"])
        elif entry["required"]:
            raise RuntimeError("Required existing CLI is missing")
        else:
            current = None
        prepared.append((destination, content, current))
    for destination, content, current in prepared:
        if current == content:
            continue
        if current is not None:
            backup = here / "backup" / destination.name
            backup.parent.mkdir(parents=True, exist_ok=True)
            if not backup.exists():
                backup.write_bytes(current)
        fd, temporary = tempfile.mkstemp(prefix=".slide_target_", dir=str(destination.parent))
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            os.chmod(temporary, 0o644)
            os.replace(temporary, str(destination))
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
    print("Installed target controls atomically. No jobs, fits, priors or simulation sources changed.")
    print("Next run the R CLI audit, then set-target PROJECT latest 40.")

if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("STOP: " + str(error), file=sys.stderr)
        sys.exit(1)
