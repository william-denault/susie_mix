"""Install optional tissue jobs. No job submission, cancellation or activation."""
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile

def digest(data):
    return hashlib.sha256(data.decode("utf-8-sig").replace("\r\n", "\n").encode("utf-8")).hexdigest()

def main():
    if len(sys.argv) != 2:
        raise RuntimeError("Usage: python3 install.py RCC_PROJECT_DIRECTORY")
    project = Path(sys.argv[1]).resolve()
    here = Path(__file__).resolve().parent
    manifest = json.loads((here / "manifest.json").read_text())
    if not (project / "results_slide_prior_em/prior_history.csv").is_file():
        raise RuntimeError("No existing slider EM history at this path")
    prepared = []
    for entry in manifest:
        destination = (project / entry["path"]).resolve()
        if project not in destination.parents:
            raise RuntimeError("Invalid destination")
        content = (here / "payload" / entry["path"]).read_bytes()
        if digest(content) != entry["sha256"]:
            raise RuntimeError("Payload checksum mismatch: " + entry["path"])
        current = destination.read_bytes() if destination.exists() else None
        if current is not None and digest(current) not in entry["accepted"]:
            raise RuntimeError("Installed file differs from reviewed versions: " + entry["path"])
        if current is None and entry["required"]:
            raise RuntimeError("Required installed file missing: " + entry["path"])
        prepared.append((entry, destination, content, current))
    enabled = project / "results_slide_prior_em/tissue_split_genes.rds"
    if enabled.exists() and any(current is None or digest(current) != digest(content)
                                for _, _, content, current in prepared):
        raise RuntimeError("Tissue splitting is already enabled; refuse to change its frozen sources")
    for entry, destination, content, current in prepared:
        if current == content:
            continue
        if current is not None:
            backup = here / "backup" / entry["path"]
            backup.parent.mkdir(parents=True, exist_ok=True)
            if not backup.exists():
                backup.write_bytes(current)
        destination.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix=".slide_tissue_", dir=str(destination.parent))
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            os.chmod(temporary, 0o755 if entry["path"].startswith("job/") else 0o644)
            os.replace(temporary, str(destination))
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
    print("Installed optional tissue workers. No genes enabled; no jobs or results changed.")
    print("The existing iteration target and shared scheduler are unchanged. See README.md for preflight and selection.")

if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("STOP: " + str(error), file=sys.stderr)
        sys.exit(1)
